
const images = [
  { src: "images/art1_16x9.jpg", ratio: "16:9" },
  { src: "images/art2_16x9.jpg", ratio: "16:9" },
  { src: "images/art3_1x1.jpg", ratio: "1:1" },
  { src: "images/art4_1x1.jpg", ratio: "1:1" }
];

let tokens = 300;

function updateTokens() {
  document.getElementById('token-count').textContent = tokens;
}

function downloadImage(src) {
  if (tokens >= 5) {
    tokens -= 5;
    updateTokens();
    const link = document.createElement('a');
    link.href = src;
    link.download = src.split('/').pop();
    link.click();
  } else {
    alert("Not enough tokens! Please recharge.");
  }
}

function displayImages(filter = "all") {
  const gallery = document.getElementById('gallery');
  gallery.innerHTML = '';
  
  images.filter(img => filter === "all" || img.ratio === filter)
        .forEach(img => {
    const card = document.createElement('div');
    card.className = 'image-card';
    card.innerHTML = `
      <img src="${img.src}" alt="AI Art">
      <button class="download-btn" onclick="downloadImage('${img.src}')">Download (5 Tokens)</button>
    `;
    gallery.appendChild(card);
  });
}

function filterImages() {
  const selectedRatio = document.getElementById('ratio').value;
  displayImages(selectedRatio);
}

// Initial Load
displayImages();
updateTokens();
